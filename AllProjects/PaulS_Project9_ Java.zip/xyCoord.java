public class xyCoord {
	int Xcoord =0;
	int Ycoord = 0;
	int Label = 0;
}
