/**
 * Author: Swrajit Paul
 */
import java.io.*;
import java.util.Scanner;

public class Kmean {
	static FileInputStream fInput = null;
    static FileOutputStream fOutputone;
    static FileOutputStream fOutputtwo;
    static FileOutputStream fOutputthree;
    
    static PrintStream ps;
    static PrintStream ps2;
    static PrintStream ps3;
    static Scanner inputfile;
    static int K; // ask user for the number of clusters
	static int numPts = 0; // initialize to 0 
	static Point pointSet[]; // 1D array of Point class
		 // to be dynamically allocated during runtime
		 // initially set all points distance to 99999 a large distance
    static int  numRows; 
    static int	numCols;
    static int	minVal;
    static int	maxVal;
    static int c = 0;
	static int[][] imgAry; // a 2D array, size of  numRows by numCols

	static xyCoord Kcentroids[]; // 1D array of xyCoord class
	// to be dynamically allocated in class constructor, size of K+1
	// we do NOT want to use 0 as cluster label so the cluster label
	// will run from 1 to K, therefore, the size of array is K+1

	int change; // for tracking the label changes, initialize to 0

	Kmean () {
		
	}
	
	public static void extractPts(int[][] ary) {
		// read from inFile and write none zero pixel to 
		// outFile_1.

		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				if(ary[i][j] > 0) {
					numPts++;
					ps.println(i + " "+ j);
				}
			}
		}
		
	}
	
	public static void loadPointSet (String s, Point[] pointSet2 ) {
		// read each point, p, from outFile_1 and store it onto
		// the pointSet array.
		// initially set p�s Distance to 9999.0 a large distance.
		// YOUR SHOULD KNOW HOW TO WRITE THIS METHOD! 	
		int index = 0;
		FileInputStream fs;
		try {
			fs = new FileInputStream(s);
			Scanner scan = new Scanner(fs);
			while(scan.hasNext()) {
				int a = Integer.parseInt(scan.next());
				int b = Integer.parseInt(scan.next());
				pointSet2[index] = new Point();
				pointSet2[index].Xcoord = a;
				pointSet2[index].Ycoord = b;
				pointSet2[index].Distance = 9999.0;
				index++;
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void assignLabel (Point[] pointSet, int K) {
		int front = 0;
		int back = numPts - 1;
		int label = 1;

		while(front <= back) {
			pointSet[front].Label = label;
			front++;
			label++;
			pointSet[back].Label = label;
			back--;
			label++;
		   
			if (label > K) {
				label = 1;
			}

		}
	}
	
	public static void kMeansClustering (Point[] pointSet2, int K) {
		int iteration = 0;
		assignLabel(pointSet2, K);
		int c = 0;
		while(c <= 0) {
			Point2Image(pointSet2, imgAry);
			printImage(iteration);
			computeCentroids (pointSet, Kcentroids);
			int index = 0;
			while(index < numPts) {
				DistanceMinLable(pointSet[index], Kcentroids); 
				index++; 
			}
			iteration++;
			
			if(iteration > 40) {
				break;
			}
		}
	
	}
	
	public static void computeCentroids (Point[] pointSet, xyCoord[] Kcentroids ) {
		// see algorithm below
		// Go thru the entire pointSet array only  once
	// to compute the centroids of each of the K clusters
	// Store the computed centroids in each Kcentroids[label], 
	// where label is from 1 to K.
		int sumX[] = new int [K+1];
		int sumY[] = new int [K+1];
		int totalPt[] = new int[K+1];
				// initialize the above 3 1D arrays to 0
		 
		int index = 0;
		
		int label = 0;
		while(index < numPts) {
			try {
				label = pointSet[index].Label; // get the point�s cluster label
				sumX[label] += pointSet[index].Xcoord;
				sumY[label] += pointSet[index].Ycoord;
				totalPt[label]++;
				index++;
			}
			catch(Exception e) {
				break;
			}
		}
		
		label = 1;
		while(label <= K){
			try {
				Kcentroids[label].Xcoord = (int) (sumX[label]/ totalPt[label]);
				Kcentroids[label].Ycoord = (int) (sumY[label]/ totalPt[label]);
				label++;
			}
			catch(Exception e) {
				break;
			}
		}

	}
	
	public static void DistanceMinLable (Point pointSet, xyCoord[] kcentroids2) { 
		int minDist = 99999;
		int minLabel = 0;
		int label = 1;
		
		while (label <= K) {
		int dist = (int) Math.ceil(computeDist(pointSet, kcentroids2[label]));
			if (dist < minDist) {
				minLabel = label;
				minDist = dist;
			}
			label++;
		}
		
		if (pointSet.Label != minLabel) { 
			pointSet.Label = minLabel;
			pointSet.Distance = minDist;
			c++;
		}
	}
	
	public static double computeDist(Point pt, xyCoord kcentroids2) {
		int x = (kcentroids2.Xcoord - pt.Xcoord);
		int y = (kcentroids2.Ycoord - pt.Ycoord);
		return Math.sqrt((x*x) - (y*y));
	}
	
	public static void writePtSet (Point[] pointSet) {
		ps3.println(pointSet.length);
		ps3.println(numRows + " " + numCols);
		for(int i = 1; i < pointSet.length; i++) {
			ps3.println(pointSet[i].Xcoord + " "+ pointSet[i].Ycoord + " " +pointSet[i].Label);
		}
	}
			
	public static void Point2Image (Point[] pointSet2, int[][] imgAry) {
		for(int i = 0; i < pointSet2.length; i++) {
			imgAry[pointSet2[i].Xcoord][pointSet2[i].Ycoord] = pointSet2[i].Label;
		}
	
	}

	public static void printImage (int iteration) {
		ps2.print("iteration number " + iteration);
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				if(imgAry[i][j] > 0) {
					ps2.print(imgAry[i][j]);
				}
				else {
					ps2.print(" ");
				}
			}
			ps2.println();
		}
	}
	
	
	
	public static void main(String[] args) {
		try {
			
			String inputone = args[0];
			String outputone = args[1];
			String outputtwo = args[2];
			String outputthree = args[3];
			
			fInput = new FileInputStream(inputone);
			fOutputone = new FileOutputStream(outputone);
			fOutputtwo = new FileOutputStream(outputtwo);
			fOutputthree = new FileOutputStream(outputthree);
		} catch (IOException e) {
			System.out.println("one of the arguments in missing or wrong");
		}
		
		
		inputfile = new Scanner(fInput);
		
		numRows = inputfile.nextInt();
		numCols = inputfile.nextInt();
		minVal = inputfile.nextInt();
		maxVal = inputfile.nextInt();
		
		imgAry = new int[numRows][numCols];
		
		Scanner s = new Scanner(System.in);
		while(true){
			System.out.print("Enter k value: ");
			String st = s.nextLine();
			
			try {
				K = Integer.parseInt(st);
				break;
			}
			catch (Exception e) {
				continue;
			}
		}
		
		System.out.println("K value accepted " + K);
		
		Kcentroids = new xyCoord[K+1];
		for(int i = 0 ; i < Kcentroids.length; i++) {
			Kcentroids[i] = new xyCoord();
		}
		ps = new PrintStream(fOutputone);
		ps2 = new PrintStream(fOutputtwo);
		ps3 = new PrintStream(fOutputthree);
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				imgAry[i][j] = inputfile.nextInt();
			}
		}
		inputfile.close();
		extractPts(imgAry);
		pointSet = new Point[numPts];
		for(int i = 0; i < pointSet.length; i++) {
			pointSet[i] = new Point();
		}
		
		loadPointSet(args[1], pointSet);
		kMeansClustering (pointSet, K);
		writePtSet(pointSet);
		
		try {
			fInput.close();
			fOutputone.close();
			fOutputtwo.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
}
