
public class Point {
	int Xcoord;
	int Ycoord;
	int Label;
	double Distance;
}
