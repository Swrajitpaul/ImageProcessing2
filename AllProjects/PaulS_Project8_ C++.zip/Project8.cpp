// Author: Swrajit Paul

#include <iostream>
#include <fstream>
#include <cmath>

using namespace std;

ifstream inFile;
ofstream outFile;
ofstream outFiletwo;
ofstream outFilethree;
ofstream outFilefour;

class image {
	
	public:
		
		int numRows;
		int numCols; 
		int minVal; 
		int maxVal; 
					
		int** mirrorFramedAry;
	    int maskRightDiag[3][3] = {{2, 1, 0}, {1, 0, -1}, {0, -1, -2}};
	    int maskLeftDiag[3][3] = {{0, 1, 2}, {-1, 0, 1}, {-2, -1, 0}}; 

	    int** SobelRightDiag;
	    int** SobelLeftDiag;
	    int** GradiantEdge;
	    
	    image() {
	    	
			inFile >> numRows;
			inFile >> numCols; 
			inFile >> minVal; 
			inFile >> maxVal;
  			
			mirrorFramedAry  = new int*[numRows+2];
			for(int i = 0; i < numRows+2; i++){
			mirrorFramedAry[i] = new int[numCols+2]; }// set up the array with proper rows and cols
			for(int i = 0; i < numRows+2; i++) {
				for(int j = 0; j < numCols+2; j++) {
					mirrorFramedAry[i][j] = 0; } }// initialize the array
					
			SobelRightDiag= new int*[numRows+2];
			for(int i = 0; i < numRows+2; i++){
				SobelRightDiag[i] = new int[numCols+2]; }// set up the array with proper rows and cols
			for(int i = 0; i < numRows+2; i++) {
				for(int j = 0; j < numCols+2; j++) {
					SobelRightDiag[i][j] = 0; } }// initialize the array
			
			SobelLeftDiag= new int*[numRows+2];
			for(int i = 0; i < numRows+2; i++){
				SobelLeftDiag[i] = new int[numCols+2]; }// set up the array with proper rows and cols
			for(int i = 0; i < numRows+2; i++) {
				for(int j = 0; j < numCols+2; j++) {
					SobelLeftDiag[i][j] = 0; } }// initialize the array
					
			GradiantEdge = new int*[numRows+2];
			for(int i = 0; i < numRows+2; i++){
				GradiantEdge[i] = new int[numCols+2]; }// set up the array with proper rows and cols
			for(int i = 0; i < numRows+2; i++) {
				for(int j = 0; j < numCols+2; j++) {
					GradiantEdge[i][j] = 0; } }// initialize the array
			
			
	    } 
	    
	    void loadImage(int** FramedAry) {
			// reads line by line from the input into zeroFramedAry
			for(int i = 1; i < numRows+1; i++) {
				for(int j = 1; j < numCols+1; j++) {
					inFile >> FramedAry[i][j]; } }

		}
		
		void MirrorFramed(int** FramedAry) {
			for(int j = 0; j < numCols+2; j++) {
				FramedAry[0][j] = FramedAry[1][j];
				FramedAry[numRows+1][j] = FramedAry[numRows][j]; }
			
			for(int j = 0; j < numRows+2; j++) {
				FramedAry[j][0] = FramedAry[j][1];
				FramedAry[j][numCols+1] = FramedAry[j][numCols]; }
		}
		
		int convolute (int i, int j, int mask[3][3]) {
			int sum = 0;
			for(int r = 0, k = i-1; r < 3, k < i+2; r++, k++){
				for(int c = 0, l = j-1; c < 3, l < j+2; c++, l++){
					sum += mask[r][c] * mirrorFramedAry[k][l];		
				}	
			}			
			return sum;
		}

		int computeGradiant(int i, int j) {
			return abs(mirrorFramedAry[i][j] - mirrorFramedAry[i][j+1]) + abs(mirrorFramedAry[i][j] - mirrorFramedAry[i+1][j]);
		}
		
		void ComputeHistogram(int** imgInAry, int* hist, int mVal) {
			
			for(int i = 0; i < numRows; i++) {
				
				for(int j = 0; j < numCols; j++) {
					
					hist[imgInAry[i][j]] += 1;
					
				}
			}
			
		}
		
		void printHist(int* hist, int l) {
			
			for(int j = 0; j < l; j++) {
				
				outFilefour << j << " " << hist[j] << endl;
			
			}
			
		}
		
		void computeThreshold (int** imgOutAry, int thr_value) {
			
			for(int i = 1; i < numRows+1; i++) {
				
				for(int j = 1; j < numCols+1; j++) {
					
					int pixel = imgOutAry[i][j];
					
					if(pixel >= thr_value) {
						imgOutAry[i][j] = 1;
					}
					else {
						imgOutAry[i][j]= 0;
					}
					
				}
			}
		}
	
		void prettyPrint (int** imgOutAry) {
			
			for(int i = 1; i < numRows+1; i++) {
				
				for(int j = 1; j < numCols+1; j++) {
					
					if(imgOutAry[i][j] > 0) {
						outFilefour << imgOutAry[i][j];
					}
					else {
						outFilefour << " ";
					}
				}
				outFilefour << endl;
			}
		}
};

int main(int argc, char *argv[]){
	
	inFile.open(argv[1]);
	
	outFile.open(argv[2]);
	
	outFiletwo.open(argv[3]);
	
	outFilethree.open(argv[4]);
	
	outFilefour.open(argv[5]);
	
	image img;
	img.loadImage(img.mirrorFramedAry);
	img.MirrorFramed(img.mirrorFramedAry);
	
	for(int i = 1; i < img.numRows+1 ; i++) {
		for(int j = 1; j < img.numCols+1 ; j++) {
			 img.SobelRightDiag[i][j] = abs(img.convolute(i, j, img.maskRightDiag));
			 img.SobelLeftDiag[i][j] = abs(img.convolute(i, j, img.maskLeftDiag));
			 img.GradiantEdge[i][j] = img.computeGradiant(i, j);
		} 
	}
	
	
	outFile << img.numRows << " " << img.numCols << " " << img.minVal << " " << img.maxVal << endl;
	outFiletwo << img.numRows << " " << img.numCols << " " << img.minVal << " " << img.maxVal << endl;
	outFilethree << img.numRows << " " << img.numCols << " " << img.minVal << " " << img.maxVal << endl;
	
	for(int i = 1; i < img.numRows+1; i++) {
		for(int j = 1; j < img.numCols+1; j++) {
			outFile << img.SobelRightDiag[i][j];
			outFiletwo << img.SobelLeftDiag[i][j];
			outFilethree << img.GradiantEdge[i][j];
		} 
		outFile << endl;
		outFiletwo << endl;
		outFilethree << endl;
	}
	
	int rightmax = 0;
	int leftmax = 0;
	int gradiantmax = 0;
	for(int i = 1; i < img.numRows+1 ; i++) {
		for(int j = 1; j < img.numCols+1 ; j++) {
			if(img.SobelRightDiag[i][j] >= rightmax){
				rightmax = img.SobelRightDiag[i][j];
			}
			if(img.SobelLeftDiag[i][j] >= leftmax){
				leftmax = img.SobelLeftDiag[i][j];
			}
			if(img.GradiantEdge[i][j] >= gradiantmax){
				gradiantmax = img.GradiantEdge[i][j];
			}
		} 
	}
	
	int hist[rightmax];
	for(int l = 0; l < rightmax; l++){
		hist[l] = 0;
	}
	
	img.ComputeHistogram(img.SobelRightDiag, hist, rightmax);
	outFilefour << "Sobels right diagonal" << endl;
	img.printHist(hist, rightmax);
	img.computeThreshold(img.SobelRightDiag, 25);
	img.prettyPrint(img.SobelRightDiag);
	
	int histtwo[leftmax];
	for(int l = 0; l < leftmax; l++){
		hist[l] = 0;
	}
	
	img.ComputeHistogram(img.SobelLeftDiag, hist, leftmax);
	outFilefour << "Sobels left diagonal" << endl;
	img.printHist(hist, leftmax);
	img.computeThreshold(img.SobelLeftDiag, 25);
	img.prettyPrint(img.SobelLeftDiag);
	
	int histthree[gradiantmax];
	for(int l = 0; l < gradiantmax; l++){
		hist[l] = 0;
	}
	
	img.ComputeHistogram(img.GradiantEdge, hist, gradiantmax);
	outFilefour << "Gradiantedge" << endl;
	img.printHist(hist, gradiantmax);
	img.computeThreshold(img.GradiantEdge, 25);
	img.prettyPrint(img.GradiantEdge);
	
	inFile.close();
	outFile.close();
	outFiletwo.close();
	outFilethree.close();
	outFilefour.close();
	return 0;
}
	
