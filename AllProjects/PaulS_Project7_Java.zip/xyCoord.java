public class xyCoord {
		public int x; // x axis
		public int y; // y axis
		
		xyCoord(int a, int b){
			x = a;
			y = b;
		}
	}