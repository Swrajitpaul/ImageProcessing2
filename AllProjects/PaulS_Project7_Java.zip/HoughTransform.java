import java.io.FileOutputStream;
import java.io.PrintStream;

/**
 * Project 7
 * Author: Swrajit Paul
 */

public class HoughTransform {
	
	public static xyCoord point;
	public static int angleInDegree;
	public static double angleInRadians; 
	public static int Hough_dist; // number of rows
	public static int Hough_angle; // number of columns
	public static int HoughMinVal;
	public static int HoughMaxVal;
	public static int[][] HoughAry; // a 2D int array size of Hough_dist by Hough_angle 

    public HoughTransform(){
    	
    }
    
	public double computeDistance (xyCoord a , double angleRadians) {
		
		return Math.sqrt((a.x*a.x)+(a.y*a.y)) * Math.cos(angleRadians - Math.atan(a.y/a.x) - Math.PI/2);
		
	}
	
	public void determineMinMax (int[][] HAry) {
		HoughMinVal = Integer.MAX_VALUE;
		HoughMaxVal = 0;
		for(int i = 0; i < HoughAry.length; i++) {
			for(int j = 0; j < HoughAry[0].length; j++) {
				if(HoughAry[i][j] >= HoughMaxVal) {
					HoughMaxVal = HoughAry[i][j];
				}
				if(HoughAry[i][j] <= HoughMinVal) {
					HoughMinVal = HoughAry[i][j];
				}
			}
		}
	}
	
	public void prettyPrint(PrintStream ps) {
		for(int i = 0; i < HoughAry.length; i++) {
			for(int j = 0; j < HoughAry[0].length; j++) {
				if(HoughAry[i][j] > 0) {
					ps.print("*");
				}
				else {
					ps.print(" ");
				}
			}
			ps.println();
		}
	}

}
