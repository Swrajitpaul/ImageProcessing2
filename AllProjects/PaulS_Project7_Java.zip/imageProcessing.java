/**
 * Project 7
 * Author: Swrajit Paul
 */

import java.io.*;
import java.util.Scanner;

public class ImageProcessing {
	
	static int numRows;
	static int numCols; 
	static int minVal; 
	static int maxVal; 
	static int[][] imgAry;
	
    static FileInputStream fInput = null;
    static FileOutputStream fOutputone;
    static FileOutputStream fOutputtwo;
    
    static Scanner inputfile;
    
    public ImageProcessing() {
    	
    } 
    
    private static void loadImage(int[][] imgAry) {	
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				imgAry[i][j] = inputfile.nextInt();
			}
		}
	}
	
	public static void main(String[] args) {
		
		try {
			
			String inputone = args[0];
			String outputone = args[1];
			String outputtwo = args[2];
			
			fInput = new FileInputStream(inputone);
			fOutputone = new FileOutputStream(outputone);
			fOutputtwo = new FileOutputStream(outputtwo);	
		} catch (IOException e) {
			System.out.println("one of the arguments in missing or wrong");
		}
		
		
		inputfile = new Scanner(fInput);
		numRows = inputfile.nextInt();
		numCols = inputfile.nextInt();
		minVal = inputfile.nextInt();
		maxVal = inputfile.nextInt();
		
		imgAry = new int[numRows][numCols];
		
		HoughTransform hf = new HoughTransform();
		hf.Hough_angle = 180;
		hf.Hough_dist = (int) Math.sqrt(numRows * numRows + numCols * numCols);   
		hf.HoughAry = new int[2*hf.Hough_dist][hf.Hough_angle];
		
		loadImage(imgAry);
		
		for(int i = 0; i < numRows; i++) {
			for(int j = 0; j < numCols; j++) {
				if(imgAry[i][j] > 0) {
					hf.point = new xyCoord(i,j);
					hf.angleInDegree = 0;
					while(hf.angleInDegree <= 179) {
						hf.angleInRadians = hf.angleInDegree* Math.PI /180.0 ;
						double dist = hf.computeDistance(hf.point, hf.angleInRadians);
						int distInt = (int)dist;
						hf.HoughAry[distInt + hf.Hough_dist][hf.angleInDegree] = hf.HoughAry[distInt + hf.Hough_dist][hf.angleInDegree]+1;
						hf.angleInDegree++;
					}
				}
			}
		}
		
		PrintStream ps = new PrintStream(fOutputone);
		hf.prettyPrint(ps);
		
		hf.determineMinMax(hf.HoughAry);
		
		PrintStream ps2 = new PrintStream(fOutputtwo);
		ps2.println(hf.Hough_dist + " " + hf.Hough_angle + " " + hf.HoughMinVal + " " + hf.HoughMaxVal);
		for(int i = 0; i < hf.HoughAry.length; i++) {
			for(int j = 0; j < hf.HoughAry[0].length; j++) {
				ps2.print(hf.HoughAry[i][j]);
			}
			ps2.println();
		}
		
		inputfile.close();
		try {
			fInput.close();
			fOutputone.close();
			fOutputtwo.close();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
	
}
